## ---- Imports ---- ##
import time
import board
from piper_blockly import *
import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.keycode import Keycode

## ---- Definitions ---- ##
value = None
GP25 = piperPin(board.GP25, "GP25")

try:
  set_digital_view(True)
except:
  pass

time.sleep(1)
keyboard_HID = Keyboard(usb_hid.devices)
keyboard_HID_layout = KeyboardLayoutUS(keyboard_HID)


## ---- Code ---- ##
time.sleep(3)
GP25.setPin(1)
while True:
  value = isNumber(value) + 1
  print(value)
  if value < 10 and value > -1:
    keyboard_HID_layout.write(('000' + str(value)))
    keyboard_HID.press(Keycode.RETURN)
    keyboard_HID.release(Keycode.RETURN)
  if value < 100 and value > 9:
    keyboard_HID_layout.write(('00' + str(value)))
    keyboard_HID.press(Keycode.RETURN)
    keyboard_HID.release(Keycode.RETURN)
  if value < 1000 and value > 99:
    keyboard_HID_layout.write(('0' + str(value)))
    keyboard_HID.press(Keycode.RETURN)
    keyboard_HID.release(Keycode.RETURN)
  if value < 10000 and value > 999:
    keyboard_HID_layout.write(('' + str(value)))
    keyboard_HID.press(Keycode.RETURN)
    keyboard_HID.release(Keycode.RETURN)

  time.sleep(0.5)
